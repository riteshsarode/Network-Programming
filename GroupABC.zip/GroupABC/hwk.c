#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include "hwk.h"
/**
 * Used in the program.Maxmimum length of command line argument
 */
#define MAXLEN 1000
 /**
 * Used in the program.Maximum length of stock name
 */
#define MAXNAMELEN 4
 /**
 * Used in the program.Withdraw fee charged from user
 */
#define WITHDRAWFEE 10
 /**
 * Used in the program.Buy fee charged from user 
 */
#define BUYFEE 8
 /**
 * Used in the program.Sell fee charged from user 
 */
#define SELLFEE 8
 /**
 * Used in the program.Quote fee charged from user
 */
#define QUOTEFEE 1
 /**
 * Used in the program.Statement fee charged from user
 */
#define STATEMENTFEE 2
 /**
 * Used in the program.If User Account value>10000,no fee is charged
 */
#define FEEWAIVE_THRESHOLD 10000

/**
 * Initiates the startup mode and if provided right commands stores the stocks and initiates transaction mode
 */
void startup_mode(){
	int i;
	printf("STARTUP MODE READY\n");
	FILE* log;
	log = fopen("log.txt","w+"); 
	int num_stocks = initialize(log);
	STOCK* stocks_db[num_stocks];
	for(i=0;i<num_stocks;i++){
		stocks_db[i] = stocks_details(log);
	}
	USER* user = malloc(sizeof(USER));
	user->balance = 0;
	user->shares = malloc(num_stocks*sizeof(SHARE));
	for(i=0;i<num_stocks;i++){
		user->shares[i].num = 0;
		user->shares[i].stk = stocks_db[i];
	}
	transaction_mode(user, stocks_db, num_stocks,log);
	cleanup(user, stocks_db, num_stocks);
	fclose(log);
}

/**
 * initializes the program
 * @param log appending text to log.txt
 * @return num_stocks
 */
int initialize(FILE* log){
	char command[MAXLEN];
	char temp[MAXLEN];
  	int num_stocks;
  	int check = 1;
	do{
		fgets(command,MAXLEN,stdin);
		if(command[strlen(command)-1] == '\n')
			command[strlen(command)-1] = '\0';
		strcpy(temp,command);
		char* token = strtok(command, " ");
		int tokens = 0;
		while(token != NULL){	
			if(tokens == 0){
				if(strcmp(token,"STOCKS") != 0){
					check = 1;
					break;
				}
			}
			else if(tokens == 1){
				num_stocks = atoi(token);
				if(num_stocks <= 0){
					check = 1;
					break;
				}
				else
					check = 0;
			}
			else{
					check = 1;
					break;
			}
			token=strtok(NULL," ");
			tokens++;
		}
		if(check == 1){
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
		}
	}while(check);
	fprintf(log,"STOCKS %d BALANCE $0 FEE $0 ----\n",num_stocks);
	fflush(log);
	//printf("%d\n",check);
	return num_stocks;
}

/**
 * Gets the information of each stock
 * @param log appending text to log.txt
 * @return stock with its value and name
 */
STOCK* stocks_details(FILE* log){
	char command[MAXLEN];
	char temp1[MAXLEN];
	int dollars,i,check = 1,check1=0;
	STOCK* temp = malloc(sizeof(STOCK));

	do{
			fgets(command,MAXLEN,stdin);
			if(command[strlen(command)-1] == '\n')
				command[strlen(command)-1] = '\0';
			strcpy(temp1,command);
			char* token = strtok(command, " ");
			int tokens = 0;
			while(token != NULL){	
				if(tokens == 0){
					if(strcmp(token,"STOCK") != 0){
						check = 1;
						break;
					}
				}
				else if(tokens == 1){
					if(strlen(token) > 4){
						check = 1;
						break;
					}
					else{
						for(i=0;i<strlen(token);i++){
							if(token[i] < 65 || token[i] > 90){
								check1 = 1;
								break;
							}
						}
						if(check1 == 1){
							check = 1;
							break;
						}
						else{
							int j;
							for(j=0;j<strlen(token);j++)
								temp->name[j]=token[j];
							temp->name[j]='\0';
						}
					}
				}
				else if(tokens == 2){
					if(token[0] == '$'){
						token[0] = '0';
						dollars = atoi(token);
						if(dollars <= 0){
						check = 1;
						break;
						}
						else
							check = 0;
					}
					else{
						check = 1;
						break;
					}
				}
				else{
					check = 1;
					break;
				}
				token=strtok(NULL," ");
				tokens++;
			}
			if(check == 1){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp1);
				fflush(log);
			}
		}while(check);
		temp->value=dollars;
		fprintf(log,"STOCK %s $%d BALANCE $0 FEE $0 ----\n",temp->name,temp->value);
		fflush(log);
		return temp;
}

/**
 * Initializes the transaction mode
 * @param user contains user details like balance and shares held
 * @param stocks_db[] contains stock details like name,value
 * @param num_stocks is the number of stocks
 * @param log appending text to log.txt
 */
void transaction_mode(USER* user, STOCK* stocks_db[], int num_stocks, FILE* log){
	char command[MAXLEN];
	char temp[MAXLEN];
	int check = 1;
  	printf("TRANSACTION MODE READY\n");
	while(fgets(command,MAXLEN,stdin)){
  	do{
  		//fgets(command,MAXLEN,stdin);
  		if(command[strlen(command)-1] == '\n')
  			command[strlen(command)-1] = '\0';
  		strcpy(temp,command);
		char* token = strtok(command, " ");
		if(strcmp(token,"BUY") == 0){
			check = buy_stock(user, stocks_db, num_stocks, temp,log);
		}
		else if(strcmp(token,"SELL") == 0){
			check = sell_stock(user,stocks_db, num_stocks,temp,log);
		}
		else if(strcmp(token,"DEPOSIT") == 0){
			check = deposit_in_account(user,temp,log);
		}
		else if(strcmp(token,"WITHDRAW") == 0){
			check = withdraw_from_account(user,stocks_db, num_stocks,temp,log);
		} 
		else if(strcmp(token,"STATEMENT") == 0){
			check = statement(user,stocks_db,num_stocks,temp,log);
		}
		else if(strcmp(token,"QUOTE") == 0){
			check = quote(user,stocks_db, num_stocks,temp,log);
		}
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			check = 1;
		}
  	}while(check && fgets(command,MAXLEN,stdin));
    	}
}

/**
 * Used to validate BUY command
 * @param user contains user details like balance and shares held
 * @param stocks_db[] contains stock details like name,value
 * @param num_stocks is the number of stocks
 * @param command is command line argument entered by user
 * @param log appending text to log.txt
 * @return 0 if transaction is successful, 1 if transaction is failed
 */
int buy_stock(USER* user, STOCK* stocks_db[], int num_stocks, char command[MAXLEN],FILE* log){
	int tokens = 0,n=0;
	int check = 1,i;
	char temp[MAXLEN];
	strcpy(temp,command);
	char* token = strtok(command," ");
	token=strtok(NULL," ");
	tokens=tokens+1;
	while(token != NULL){
		if(tokens == 1){
			for(i=0;i<num_stocks;i++){
				if(strcmp(stocks_db[i]->name,token)==0){
					break;
				}
			}
			if(i==num_stocks){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
		}
		else if(tokens == 2){
			n=atoi(token);
			if(n <= 0 || n > 100){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
			else
				check = 0;
		}
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			return 1;
		}
		token = strtok(NULL," ");
		tokens++;
	}
	if(check == 0){
		int buyFee = BUYFEE; int j;
		int present_userproperty = user->balance;
		for(j=0;j<num_stocks;j++){
			if(strcmp(stocks_db[j]->name,"-1")!=0){
				present_userproperty = present_userproperty+((user->shares[j].num)*(user->shares[j].stk->value));
			}
		}
		if(present_userproperty >= FEEWAIVE_THRESHOLD)
			buyFee=0;
		int total = n*(user->shares[i].stk->value);
		if(user->balance >= total+buyFee){
			user->shares[i].num = user->shares[i].num + n;
			user->balance=(user->balance)-total-buyFee;
			//user->share[i].stk->value = (user->share[i].stk->value) - 1;
			int temp1 = stocks_db[i]->value;
			stocks_db[i]->value = stocks_db[i]->value - 1;
			printf("%d SHARES OF %s BOUGHT FOR $%d TOTAL ~~~ BALANCE NOW $%d\n",n,user->shares[i].stk->name,total,user->balance);
			fprintf(log,"%s BALANCE $%d FEE $%d %s %d $%d $%d\n",temp,user->balance,buyFee,stocks_db[i]->name,n,temp1,stocks_db[i]->value);
			fflush(log);
			if(stocks_db[i]->value == 0){
				strcpy(stocks_db[i]->name,"-1");
			}
			return 0;
		}
		else{
			printf("INSUFFICIENT FUNDS\n");
			fprintf(log,"%s INSUFFICIENT FUNDS\n",temp);
			fflush(log);
			return 0;
		}
	}
	else
		printf("ERROR INVALID INPUT\n");
		fprintf(log,"%s ERROR INVALID INPUT\n",temp);
		fflush(log);
		return 1;
}

 /**
 * Used to validate SELL command
 * @param user contains user details like balance and shares held
 * @param stocks_db[] contains stock details like name,value
 * @param num_stocks is the number of stocks
 * @param command is command line argument entered by user
 * @param log appending text to log.txt
 * @return 0 if transaction is successful, 1 if transaction is failed
 */
int sell_stock(USER* user, STOCK* stocks_db[], int num_stocks, char command[MAXLEN],FILE* log){
	int tokens = 0,n=0;
	int check = 1,i;
	char temp[MAXLEN];
	strcpy(temp,command);
	char* token = strtok(command," ");
	token=strtok(NULL," ");
	tokens=tokens+1;
	while(token != NULL){
		if(tokens == 1){
			for(i=0;i<num_stocks;i++){
				if(strcmp(stocks_db[i]->name,token)==0){
					break;
				}
			}
			if(i==num_stocks){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
		}
		else if(tokens == 2){
			n=atoi(token);
			if(n <= 0 || n > 100){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
			else
				check = 0;
		}
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			return 1;
		}
		token = strtok(NULL," ");
		tokens++;
	}
	if(check == 0){
		int sellFee = SELLFEE; int j;
		int present_userproperty = user->balance;
		for(j=0;j<num_stocks;j++){
			if(strcmp(stocks_db[j]->name,"-1")!=0){
				present_userproperty = present_userproperty+((user->shares[j].num)*(user->shares[j].stk->value));
			}
		}
		if(present_userproperty >= FEEWAIVE_THRESHOLD)
			sellFee=0;
		int total = n*(user->shares[i].stk->value);
		if(user->balance >= sellFee){
			if(user->shares[i].num<n){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
			user->shares[i].num = user->shares[i].num - n;
			user->balance=(user->balance)+total-sellFee;
			//user->share[i].stk->value = (user->share[i].stk->value) - 1;
			int temp1 = stocks_db[i]->value;
			stocks_db[i]->value = stocks_db[i]->value + 1;
			printf("%d SHARES OF %s SOLD FOR $%d TOTAL ~~~ BALANCE NOW $%d\n",n,user->shares[i].stk->name,total,user->balance);
			fprintf(log,"%s BALANCE $%d FEE $%d %s %d $%d $%d\n",temp,user->balance,sellFee,stocks_db[i]->name,n,temp1,stocks_db[i]->value);
			fflush(log);
			return 0;
		}
		else{
			printf("INSUFFICIENT FUNDS\n");
			fprintf(log,"%s INSUFFICIENT FUNDS\n",temp);
			fflush(log);
			return 0;
		}
	}
	else
		printf("ERROR INVALID INPUT\n");
		fprintf(log,"%s ERROR INVALID INPUT\n",temp);
		fflush(log);
		return 1;
}
/**
 * Used to validate DEPOSIT command
 * @param user contains user details like balance and shares held
 * @param command is command line argument entered by user
 * @param log appending text to log.txt
 * @return 0 if transaction is successful, 1 if transaction is failed
 */
int deposit_in_account(USER *user, char command[MAXLEN],FILE* log){
	int tokens = 0;
	int check = 1;
	int deposit = 0;
	char temp[MAXLEN];
	strcpy(temp,command); 
	char* token = strtok(command," ");
	while(token != NULL){
				if(tokens == 0){
					if(strcmp(token,"DEPOSIT") != 0){
						printf("ERROR INVALID INPUT\n");
						fprintf(log,"%s ERROR INVALID INPUT\n",temp);
						fflush(log);
						return 1;
					}
				}
				else if(tokens == 1){
					if(token[0] == '$'){
						token[0] = '0';
						deposit = atoi(token);
						if(deposit <= 0){
							printf("ERROR INVALID INPUT\n");
							fprintf(log,"%s ERROR INVALID INPUT\n",temp);
							fflush(log);
							check = 1;
							return 1;
						}
						else
							check = 0;
					}
					else{
						printf("ERROR INVALID INPUT\n");
						fprintf(log,"%s ERROR INVALID INPUT\n",temp);
						fflush(log);
						check = 1;
						return 1;
					}	
				}
				else{
					printf("ERROR INVALID INPUT\n");
					fprintf(log,"%s ERROR INVALID INPUT\n",temp);
					fflush(log);
					check = 1;
					return 1;
				}
				token = strtok(NULL," ");
				tokens++;
			}
			if(check == 0){
				user->balance = user->balance + deposit;
				printf("$%d DEPOSITED ~~~ BALANCE NOW $%d\n",deposit,user->balance);
				fprintf(log,"%s BALANCE $%d FEE $0 - - - -\n",temp,user->balance);
				fflush(log);
				return 0;
			}
			else{
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
}

 /**
 * Used to validate WITHDRAW command
 * @param user contains user details like balance and shares held
 * @param stocks_db[] contains stock details like name,value
 * @param num_stocks is the number of stocks
 * @param command is command line argument entered by user
 * @param log appending text to log.txt
 * @return 0 if transaction is successful, 1 if transaction is failed
 */
int withdraw_from_account(USER* user,STOCK* stocks_db[], int num_stocks, char command[MAXLEN],FILE* log){
	int tokens = 0;
	int check = 1;
	int withdraw = 0;
	char temp[MAXLEN];
	strcpy(temp,command);
	char* token = strtok(command," ");
	while(token != NULL){
		if(tokens == 0){
			if(strcmp(token,"WITHDRAW") != 0){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				check = 1;
				return 1;
			}
		}
		else if(tokens == 1){
			if(token[0] == '$'){
				token[0] = '0';
				withdraw = atoi(token);
				if(withdraw <= 0){
					printf("ERROR INVALID INPUT\n");
					fprintf(log,"%s ERROR INVALID INPUT\n",temp);
					fflush(log);
					check = 1;
					return 1;
				}
				else
					check = 0;
			}
			else{
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				check = 1;
				return 1;
			}
		}	
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			check = 1;
			return 1;
		}
		token = strtok(NULL," ");
		tokens++;
	}
	if(check == 0){
		int withdrawFee = WITHDRAWFEE,j;
		int present_userproperty = user->balance;
		for(j=0;j<num_stocks;j++){
			if(strcmp(stocks_db[j]->name,"-1")!=0){
				present_userproperty = present_userproperty+((user->shares[j].num)*(user->shares[j].stk->value));
			}
		}
		if(present_userproperty >= FEEWAIVE_THRESHOLD)
			withdrawFee=0;
		//int total = n*(user->shares[i].stk->value);
		if(user->balance >= (withdraw+withdrawFee)){
			user->balance = (user->balance)-withdraw-withdrawFee;
			printf("HERE IS YOUR $%d ~~~ BALANCE NOW $%d\n",withdraw,user->balance);
			fprintf(log, "%s BALANCE $%d FEE $%d ----\n",temp,user->balance,withdrawFee );
			fflush(log);
			return 0;
		}
		else{
			printf("INSUFFICIENT FUNDS\n");
			fprintf(log,"%s INSUFFICIENT FUNDS\n",temp);
			fflush(log);
			return 0;
		}
	}
	else{
		printf("ERROR INVALID INPUT\n");
		fprintf(log,"%s ERROR INVALID INPUT\n",temp);
		fflush(log);
		return 1;
		}

}

 /**
 * Used to validate STATEMENT command
 * @param user contains user details like balance and shares held
 * @param stocks_db[] contains stock details like name,value
 * @param num_stocks is the number of stocks
 * @param command is command line argument entered by user
 * @param log appending text to log.txt
 * @return 0 if transaction is successful, 1 if transaction is failed
 */
int statement(USER* user,STOCK* stocks_db[], int num_stocks,char command[MAXLEN],FILE* log){
	int tokens = 0;
	int check =0,i,check1 = 0;
	char temp[MAXLEN];
	strcpy(temp,command);
	char* token = strtok(command," ");
	tokens=tokens+1;
	token=strtok(NULL," ");
	//tokens=tokens+1;
	while(token != NULL){
		if(tokens == 1){
			if(strcmp(token,"STATEMENT") != 0){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				check = 1;
				return 1;
			}
		}
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			check = 1;
			return 1;
		}	
		tokens++;
		token=strtok(command,"NULL");
	}
	if(check == 0){
		int statementFee = STATEMENTFEE;int j;int share_value=0;
		int present_userproperty = user->balance;
		for(j=0;j<num_stocks;j++){
			if(strcmp(stocks_db[j]->name,"-1")!=0){
				present_userproperty = present_userproperty+((user->shares[j].num)*(user->shares[j].stk->value));
			}
		}
		if(present_userproperty >= FEEWAIVE_THRESHOLD)
			statementFee=0;
		if(user->balance >= statementFee){
			user->balance = user->balance - statementFee;
			printf("BALANCE NOW $%d\n",user->balance);
			fprintf(log,"%s BALANCE $%d FEE $%d ----\n",temp,user->balance,statementFee);
			fflush(log);
			for(i=0;i<num_stocks;i++){
				if(strcmp(user->shares[i].stk->name,"-1")!=0 && (user->shares[i].num!= 0)){
					check1 = 1;
					break;
				}
			}
			if(check1 == 1){
				printf("STOCK\tSHARES\tPRICE\tTOTAL\n");
				for(i=0;i<num_stocks;i++){
					if(strcmp(stocks_db[i]->name,"-1") != 0 && (user->shares[i].num!= 0)){
						int temp = user->shares[i].stk->value*user->shares[i].num;
						printf("%s\t%d\t%d\t%d\n",user->shares[i].stk->name,user->shares[i].num,user->shares[i].stk->value,temp);
						share_value = share_value+temp;
					}
				}
			}
			printf("ACCOUNT VALUE $%d\n",present_userproperty-statementFee);
			return 0;
		}
		else{
			printf("INSUFFICIENT FUNDS\n");
			fprintf(log,"%s INSUFFICIENT FUNDS\n",temp);
			fflush(log);
			return 0;
		}
	}
	else{
		printf("ERROR INVALID INPUT\n");
		fprintf(log,"%s ERROR INVALID INPUT\n",temp);
		fflush(log);
		return 1;
	}
		
}

 /**
 * Used to validate QUOTE command
 * @param user contains user details like balance and shares held
 * @param stocks_db[] contains stock details like name,value
 * @param num_stocks is the number of stocks
 * @param command is command line argument entered by user
 * @param log appending text to log.txt
 * @return 0 if transaction is successful, 1 if transaction is failed
 */
int quote(USER* user,STOCK *stocks_db[], int num_stocks, char command[MAXLEN],FILE* log){
	int tokens = 0;
	int check = 1,i;
	char temp[MAXLEN];
	strcpy(temp,command);
	char* token = strtok(command," ");
	token=strtok(NULL," ");
	tokens=tokens+1;
	while(token != NULL){
		if(tokens == 1){
			for(i=0;i<num_stocks;i++){
				if(strcmp(stocks_db[i]->name,token)==0){
					break;
				}
			}
			if(i==num_stocks){
				printf("ERROR INVALID INPUT\n");
				fprintf(log,"%s ERROR INVALID INPUT\n",temp);
				fflush(log);
				return 1;
			}
			else{
				check = 0;
			}
		}
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			return 1;
		} 
		token = strtok(NULL," ");
		tokens++;
		}
		if(check == 0){
				int quoteFee = QUOTEFEE; int j;
				int present_userproperty = user->balance;
				for(j=0;j<num_stocks;j++){
					if(strcmp(stocks_db[j]->name,"-1")!=0){
						present_userproperty = present_userproperty+((user->shares[j].num)*(user->shares[j].stk->value));
					}
				}
				if(present_userproperty >= FEEWAIVE_THRESHOLD)
					quoteFee=0;
			if(user->balance >= quoteFee){
				int temp1 = stocks_db[i]->value;
				if(user->shares[i].num>=1)	
					stocks_db[i]->value = stocks_db[i]->value-1;
				else
					stocks_db[i]->value = stocks_db[i]->value+1;
				user->balance = user->balance-quoteFee;
				printf("%s IS $%d\n",stocks_db[i]->name,stocks_db[i]->value);
				fprintf(log,"%s BALANCE $%d FEE $%d %s - $%d $%d\n",temp,user->balance,quoteFee,stocks_db[i]->name,temp1,stocks_db[i]->value);
				fflush(log);
				if(stocks_db[i]->value == 0){
					strcpy(stocks_db[i]->name,"-1");
				}
				
				return 0;
			}
			else{
				printf("INSUFFICIENT FUNDS\n");
				fprintf(log,"%s INSUFFICIENT FUNDS\n",temp);
				fflush(log);
				return 0;
			}
		}
		else{
			printf("ERROR INVALID INPUT\n");
			fprintf(log,"%s ERROR INVALID INPUT\n",temp);
			fflush(log);
			return 1;
		}
	
}

/**
* Cleans up Dynamically allocated memory
* @param user contains user details like balance and shares held
* @param stocks_db[] contains stock details like name,value
* @param num_stocks is the number of stocks
*/
void cleanup(USER* user, STOCK* stocks_db[], int num_stocks){
	int i;
	for(i=0;i<num_stocks;i++){
		free(stocks_db[i]);
		stocks_db[i] = NULL;
		//free(user->shares[i]);
	}
	free(user->shares);
	user->shares = NULL;
	free(user);
	user = NULL;
}