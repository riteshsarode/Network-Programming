/**
 * @file main.c
 * @author Justin Yackoski
 * @brief This is the main file that starts the program.
 */
#include "hwk.h"

/**
 * This is the main function that starts the program.
 * @param argc the number of arguments
 * @param argv the command line arguments 
 *   (the 0th argument is the program name)
 * @return the exit code of the program
 */


int main(int argc, char *argv[]){
	startup_mode();
  	return 0;
}

