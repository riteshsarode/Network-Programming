/**
 * @file hwk.h
 * @author GroupABC
 * @brief This is the header file.
 */
#ifndef HWK_H
#define HWK_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/**
 * Used in the program.Maxmimum length of command line argument
 */
#define MAXLEN 1000
 /**
 * Used in the program.Maximum length of stock name
 */
#define MAXNAMELEN 4
/**
 * This is my database.
 * Used to store stock name and value
 */
typedef struct STOCK{
  char name[MAXNAMELEN+1]; ///<name of stock
  int value; ///<value of stock
}STOCK;

/**
 * This is my database.
 * Used to store user's shares of a particular stock
 */
typedef struct SHARE{
  int num; ///<number of shares of particular stock hold by user
  STOCK* stk; ///<particular stock
}SHARE;

/**
 * This is my database.
 * Used to store user's balance and shares
 * @param balance balance of user
 * @param shares all shares of user
 */
typedef struct USER{
  int balance; ///<balance of user
  SHARE* shares; ///<all shares of user
}USER;

//str

void startup_mode();
int initialize(FILE* log);
STOCK* stocks_details(FILE* log);
void transaction_mode(USER* user, STOCK* stocks_db[], int num_stocks,FILE* log);
int buy_stock(USER* user, STOCK* stocks_db[], int num_stocks, char command[MAXLEN],FILE* log);
int sell_stock(USER* user, STOCK* stocks_db[], int num_stocks, char command[MAXLEN],FILE* log);
int deposit_in_account(USER *user, char command[MAXLEN],FILE* log);
int withdraw_from_account(USER* user,STOCK* stocks_db[], int num_stocks, char command[MAXLEN],FILE* log);
int statement(USER* user,STOCK* stocks_db[], int num_stocks,char command[MAXLEN],FILE* log);
void cleanup(USER* user, STOCK* stocks_db[], int num_stocks);
int quote(USER* user,STOCK *stocks_db[], int num_stocks, char command[MAXLEN],FILE* log);

#endif
