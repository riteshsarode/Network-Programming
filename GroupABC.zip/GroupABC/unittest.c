/**
 * @file unittest.c
 * @author GroupABC
 * @brief This file contains my unit tests.
 */
#include <stddef.h>
#include <stdarg.h>
#include <setjmp.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <cmocka.h>
#include "hwk.h"

/**
 * This is used in unittest
 */
STOCK *GOOG[1];
/**
 * This is used in unittest
 */
 SHARE *usershare;
 /**
 * This is used in unittest
 */
 USER *user;
  
/**
 * This functions sets up the tests.
 * @param state the CMocka state
 */
static int test_setup(void **state)
{
	//initialize(10);
	GOOG[0] = malloc(sizeof(STOCK));
	strcpy(GOOG[0]->name,"GOOG");
	GOOG[0]->value = 100;
	usershare = malloc(sizeof(SHARE));
	usershare->stk = GOOG[0];
	user = malloc(sizeof(USER));
	user->shares = usershare;

	return 0;
}
/**
 * This functions tests deposit_in_account
 * @param state the CMocka state
 */
static void test1(void **state)
{
	FILE* log = fopen("log.txt","w+");
	char c[100] = "DEPOSIT $10000";
	assert_int_equal(deposit_in_account(user, c,log),0);
	
}

/**
 * This functions tests withdraw_from_account
 * @param state the CMocka state
 */
static void test2(void **state)
{
	FILE* log = fopen("log.txt","w+");
	char c[100] = "WITHDRAW $5000";
	assert_int_equal(withdraw_from_account(user,GOOG, 1, c,log),0);
	
}
/**
 * This functions tests buy_stock
 * @param state the CMocka state
 */
static void test3(void **state)
{
	FILE* log = fopen("log.txt","w+");
	char c[100] = "BUY GOOG 5";
	assert_int_equal(buy_stock(user, GOOG, 1, c,log),0);
}
/**
 * This functions tests sell_stock
 * @param state the CMocka state
 */
static void test4(void **state)
{
	FILE* log = fopen("log.txt","w+");
	char c[100] = "SELL GOOG 2";
	assert_int_equal(sell_stock(user,GOOG, 1,c,log),0);
}
/**
 * This functions tests statement
 * @param state the CMocka state
 */
static void test5(void **state)
{
	FILE* log = fopen("log.txt","w+");
	char c[100] = "STATEMENT";
	assert_int_equal(statement(user,GOOG, 1,c,log),0);
}
/**
 * This functions tests quote
 * @param state the CMocka state
 */
static void test6(void **state)
{
	FILE* log = fopen("log.txt","w+");
	char c[100] = "QUOTE GOOG";
	assert_int_equal(quote(user,GOOG, 1,c,log),0);
}
/**
 * This functions cleans up after the tests.
 * @param state the CMocka state
 */
static int test_teardown(void **state)
{
	cleanup(user, GOOG, 1);
	return 0;
}

/**
 * This function starts the test program.
 * @return the exit code of the program
 */
int main(void)
{
	const struct CMUnitTest tests[] =
	{
		cmocka_unit_test(test1),
		cmocka_unit_test(test2),
		cmocka_unit_test(test3),
		cmocka_unit_test(test4),
		cmocka_unit_test(test5),
		cmocka_unit_test(test6),

	};
	return  cmocka_run_group_tests(tests, test_setup, test_teardown);
}
